/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_447()
{
    return 2428995912U;
}

unsigned addval_180(unsigned x)
{
    return x + 2421726877U;
}

void setval_308(unsigned *p)
{
    *p = 2425393232U;
}

void setval_320(unsigned *p)
{
    *p = 3284633672U;
}

unsigned getval_332()
{
    return 2425379052U;
}

void setval_331(unsigned *p)
{
    *p = 2425387016U;
}

unsigned addval_196(unsigned x)
{
    return x + 2428995912U;
}

unsigned addval_264(unsigned x)
{
    return x + 3347671209U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_456(unsigned x)
{
    return x + 3224945033U;
}

void setval_405(unsigned *p)
{
    *p = 3767093464U;
}

unsigned addval_426(unsigned x)
{
    return x + 3676362377U;
}

unsigned getval_268()
{
    return 3682912905U;
}

unsigned getval_495()
{
    return 3372269961U;
}

unsigned addval_162(unsigned x)
{
    return x + 3224947337U;
}

unsigned addval_315(unsigned x)
{
    return x + 3532966537U;
}

void setval_304(unsigned *p)
{
    *p = 2429976986U;
}

void setval_411(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_167(unsigned x)
{
    return x + 3264272009U;
}

unsigned getval_333()
{
    return 2464188744U;
}

unsigned addval_229(unsigned x)
{
    return x + 3676886665U;
}

unsigned getval_140()
{
    return 3677935240U;
}

void setval_475(unsigned *p)
{
    *p = 3286272328U;
}

void setval_100(unsigned *p)
{
    *p = 3682910665U;
}

void setval_446(unsigned *p)
{
    *p = 3380923021U;
}

unsigned addval_141(unsigned x)
{
    return x + 214157960U;
}

unsigned getval_253()
{
    return 2430642504U;
}

unsigned addval_497(unsigned x)
{
    return x + 3531915529U;
}

unsigned getval_245()
{
    return 3373842825U;
}

void setval_416(unsigned *p)
{
    *p = 2430642504U;
}

unsigned addval_280(unsigned x)
{
    return x + 3682915977U;
}

unsigned addval_278(unsigned x)
{
    return x + 2463533350U;
}

unsigned addval_372(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_382(unsigned x)
{
    return x + 3247491721U;
}

unsigned addval_130(unsigned x)
{
    return x + 2244204161U;
}

unsigned getval_218()
{
    return 3676881289U;
}

unsigned addval_177(unsigned x)
{
    return x + 3526934921U;
}

unsigned getval_493()
{
    return 3397472010U;
}

unsigned addval_255(unsigned x)
{
    return x + 3525888649U;
}

void setval_465(unsigned *p)
{
    *p = 2464188744U;
}

void setval_393(unsigned *p)
{
    *p = 2425405835U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
